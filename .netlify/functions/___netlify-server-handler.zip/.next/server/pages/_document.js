var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__334aff55._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f1341afc._.js")
R.m(39141)
module.exports=R.m(39141).exports
