module.exports=[53787,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},47290,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(53787).default,width:256,height:256}}];

//# sourceMappingURL=app_0ef037c1._.js.map