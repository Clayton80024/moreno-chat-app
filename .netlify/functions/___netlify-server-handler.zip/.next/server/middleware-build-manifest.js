globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/e6e36e55f3602da4.js",
      "static/chunks/turbopack-8736f8323a8c7075.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/e6e36e55f3602da4.js",
      "static/chunks/turbopack-d387c4788816c013.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5d42197f764f004e.js",
    "static/chunks/5daf9879421e1556.js",
    "static/chunks/41b7ffe39f379957.js",
    "static/chunks/63dba52cde864d84.js",
    "static/chunks/4efdfd2b96d7c1e5.js",
    "static/chunks/turbopack-76efe610225a0540.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];